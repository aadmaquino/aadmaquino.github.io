###############################################################

Calculadora de Derivadas
Vers�o 1.0

###############################################################

-----------------------------
Requisitos M�nimos de Sistema
-----------------------------

Sistema Operacional: Windows XP/Vista/7/8
Processador: Intel ou AMD x86/x64
Mem�ria: 512 MB de RAM

* O Programa "Calculadora de Derivadas" necessita do Microsoft
.NET Framework 4 instalado na m�quina para ser executado
(instala��o inclusa no CD - requer conex�o com a Internet).

------------------------------
Sobre Calculadora de Derivadas
------------------------------

Programa desenvolvido por:

Ad�lcio Silva
Ant�nio Augusto
Guilherme Borges
Larissa Dantas

Alunos do curso Ci�ncia da Computa��o, na FUMEC

Professora: Stella

###############################################################