=========================================================================
|       SisPortaria - Sistema de Controle de Visita (vers�o 1.0)        |
=========================================================================
|                                                                       |
| SO suportados: Windows 7/8/10                                         |
| Vers�o m�nima do Java: 1.8.0.111                                      |
| Desenvolvido por: Ant�nio Augusto Duarte                              |
|                                                                       |
| www.aadmaquino.com.br                                                 |
|                                                                       |
=========================================================================
|                                                                       |
| Passo a passo da instala��o:                                          |
|                                                                       |
=========================================================================
|                                                                       |
| 1- Baixe e instale o Java                                             |
| https://www.java.com/pt_BR/                                           |
|                                                                       |
| 2- Baixe e instale o JDK (opcional)                                   |
| http://www.oracle.com/technetwork/pt/java/javase/downloads/index.html |
|                                                                       |
| 3- Baixe e instale o Firebird 2.5                                     |
| https://www.firebirdsql.org/en/firebird-2-5                           |
|                                                                       |
| 4- Copie o arquivo 'BDPORTARIA.GDB' na Unidade C:\                    |
| Exemplo do caminho => C:\BDPORTARIA.GDB                               |
|                                                                       |
| 5- Execute o arquivo 'SisPortaria.jar'                                |
|                                                                       |
| 6- Pronto!                                                            |
|                                                                       |
=========================================================================